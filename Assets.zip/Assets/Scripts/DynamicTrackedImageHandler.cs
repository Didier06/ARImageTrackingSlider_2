using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using System.Collections.Generic;

public class DynamicTrackedImageHandler : MonoBehaviour
{
    public ARTrackedImageManager imageManager;
    public GameObject[] prefabs; // liste assignée dans l'inspecteur
    private int currentPrefabIndex = 0;
    private Dictionary<string, GameObject> spawnedPrefabs = new();

    void OnEnable()
    {
        imageManager.trackedImagesChanged += OnTrackedImagesChanged;
    }

    void OnDisable()
    {
        imageManager.trackedImagesChanged -= OnTrackedImagesChanged;
    }

    public void SwitchToNextPrefab()
    {
        currentPrefabIndex = (currentPrefabIndex + 1) % prefabs.Length;
        Debug.Log("Prefab actif : " + prefabs[currentPrefabIndex].name);
    }

    void OnTrackedImagesChanged(ARTrackedImagesChangedEventArgs args)
    {
        foreach (var trackedImage in args.added)
        {
            string imageName = trackedImage.referenceImage.name;

            if (spawnedPrefabs.ContainsKey(imageName))
                Destroy(spawnedPrefabs[imageName]);

            GameObject instance = Instantiate(prefabs[currentPrefabIndex], trackedImage.transform);
            spawnedPrefabs[imageName] = instance;
        }
    }
}

